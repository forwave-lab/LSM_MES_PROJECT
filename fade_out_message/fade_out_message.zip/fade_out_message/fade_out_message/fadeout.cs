﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fade_out_message
{
    class fadeout
    {
        public void fadeoutcontrol(object Panel,string Message)
        {

        }
    }
}
