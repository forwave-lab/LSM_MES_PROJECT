﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Milling_Marking
{
    public partial class Form1 : Form
    {
        MarkingSocket.MarkingSocket MS = new MarkingSocket.MarkingSocket();

        string port;
        string baud;
        string databits;
        string parity;
        string stop;

        public Form1()
        {
            InitializeComponent();
            this.btn_Open.Click += new System.EventHandler(this.Serial_Open);
            this.btn_Close.Click += new System.EventHandler(this.Serial_Close);
            this.btn_Send.Click += new System.EventHandler(this.Serial_Send);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string port = "COM5";
            string baud = "9600";
            string databits = "8";
            string parity = "None";
            string stop = "One";
        }

        private void Serial_Open(object sender, EventArgs e)
        {
            this.label1.Text = MS.Comport_Open("COM5", "9600", "8", "None", "One");           
        }

        private void Serial_Close(object sender, EventArgs e)
        {
            MS.CloseSerialComm();
            this.label1.Text = "Colse";
        }

        private void Serial_Send(object sender, EventArgs e)
        {
            
            byte STX = (byte)0x02;         
            byte ETX = (byte)0x03;
            byte SOH = (byte)0x01;
            byte EOT = (byte)0x04;
            byte BEL = (byte)0x07;
            byte ENQ = (byte)0x05;
            byte SO = (byte)0x0E;
            byte SI = (byte)0x0F;
            byte ACK = (byte)0x06;
            byte NAK = (byte)0x15;

            string FOLDER_FILENAME = "02" + ":" + "23";
            string strMarking = (char)STX + FOLDER_FILENAME + (char)ETX + (char)STX + textBox1.Text + (char)SOH + (char)SO + (char)BEL;// + (char)ETX

            //string sSTX = STX.ToString("X2");
           // string sETX = ETX.ToString("X2");

            //int ss = Convert.ToInt32(sSTX, 16);
            //int ee = Convert.ToInt32(sETX, 16);

            byte[] sdata1 = ASCIIEncoding.ASCII.GetBytes(strMarking);
            byte[] sdata = Encoding.GetEncoding(949).GetBytes(strMarking);

            byte[] bytes = new byte[sdata.Length + 2];
            Array.Copy(sdata, bytes, sdata.Length);
            //bytes[0] = STX;
            //bytes[bytes.Length - 1] = ETX;

            ListAdd(ASCIIEncoding.Default.GetString(sdata));
            

            //port.Write(bytes, 0, bytes.Length);

            
            //byte[] StrByte = Encoding.UTF8.GetBytes(SendData);
            //MS.SendSerialComm(bytes, bytes.Length);
            MS.SendSerialComm(sdata, sdata.Length);
        }


        private void ListAdd(string Msg)
        {
            this.listBox1.Items.Add(Msg);
        }
    }
}
